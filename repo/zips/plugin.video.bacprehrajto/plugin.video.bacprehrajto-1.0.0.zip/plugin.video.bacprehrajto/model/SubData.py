class SubData(object):
    label = ""
    path = ""

    def __init__(self, label, path):
        self.label = label
        self.path = path
