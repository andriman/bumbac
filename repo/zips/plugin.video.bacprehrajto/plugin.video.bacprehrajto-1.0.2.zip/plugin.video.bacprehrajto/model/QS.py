from enum import Enum

'''Quality selector'''
class QS(Enum):
    Max = 1
    BestCompressed = 2
    Selector = 3
